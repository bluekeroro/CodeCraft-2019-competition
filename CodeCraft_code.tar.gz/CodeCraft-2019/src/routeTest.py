# -*- coding:UTF-8 -*-

"""
对路线进行测试
"""

import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)
from lib.car import generateCarInstances
from lib.road import generateRoadInstances
from lib.map import Map
from lib.shortestpath import getShortestPath

if __name__ == '__main__':
    configCrossPath = '../config/cross.csv'
    configRoadPath = '../config/road.csv'
    configCarPath = '../config/car.csv'

    trafficMap = Map(configCrossPath, configRoadPath)
    roads = generateRoadInstances(configRoadPath)
    cars = generateCarInstances(configCarPath)

    roadRelation = trafficMap.roadRelation

    fcnt,alld = 0,0
    path = getShortestPath(trafficMap, roads, cars)
    for carId in sorted(cars.keys()):
        src = cars[carId].srcCross
        dst = cars[carId].dstCross
        print(carId,' ',end='')
        for i in range(len(path[src][dst]['path'])-1):
            curRoad = path[src][dst]['path'][i]
            nextRoad = path[src][dst]['path'][i+1]
            direction = roadRelation[curRoad][nextRoad]
            print(direction,'- ',end='')
            alld += 1
            if direction == 'forward':
                fcnt +=1

        print('')
    print(fcnt,alld)
